﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab1
{
    /// <summary>
    /// Interaction logic for ProjectDetails.xaml
    /// </summary>
    public partial class ProjectDetails : Window
    {
        public ProjectDetails()
        {
            InitializeComponent();
        }

       
        public ProjectDetails(string projectName, string budget, string spent, string estTimeRemaining, string projectStatus)
        {
        InitializeComponent();
        txtProjectName.Text = projectName;
        txtBudget.Text = budget;
        txtSpent.Text = spent;
        txtEstTimeRemaining.Text = estTimeRemaining;
        comboBoxStatus.SelectedItem = projectStatus;
        }


        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
