﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    
    class Project
    {
        public Project(string ProjectName, decimal Budget, decimal Spent, int Time, string Status)
        {

        }
    }
}
