﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes; 
namespace Lab1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<Program> program = new List<Program>();
        public MainWindow()
        {
            InitializeComponent();
        }

        public bool ValidateInput(string inputName, string inputBudget, string inputSpent, string inputTimeReamining, string inputStatus)
        {
            string errorMessage = "";
            string errorTtile = "";
            if(inputName == "")
            {
                errorMessage = "Please enter something in the Project Name field";
                errorTtile = "Invalid Project Name";
                txtProjectName.SelectAll();
                txtProjectName.Focus();
            }
            else if(!double.TryParse(inputBudget, out double a))
            {
                errorMessage = "Please enter a number!!";
                errorTtile = "Invalid Budget Amount";
                txtBudget.SelectAll();
                txtBudget.Focus();
            }
            else if(!double.TryParse(inputSpent, out double b))
            {
                errorMessage = "Please enter a number!!";
                errorTtile = "Invalid Spent Amount";
                txtSpent.SelectAll();
                txtSpent.Focus();
            }
            else if(!Int32.TryParse(inputTimeReamining, out Int32 c1 ))
            {
                errorMessage = "Please enter a number!!";
                errorTtile = "Invalid Est. Time Reamining";
                txtEstTimeRemaining.SelectAll();
                txtEstTimeRemaining.Focus();
                
            }
            else if(Int32.TryParse(inputTimeReamining, out Int32 c))
            {
                if (c < 0)
                {
                    errorMessage = "Please enter a whole number!!";
                    errorTtile = "Invalid Est. Time Reamining";
                    txtEstTimeRemaining.SelectAll();
                    txtEstTimeRemaining.Focus();
                }
                else if (inputStatus == "Completed")
                {
                    errorMessage = "Status is completed, Time Remaining must be 0!!";
                    errorTtile = "Invalid Est. Time Reamining";
                    txtEstTimeRemaining.SelectAll();
                    txtEstTimeRemaining.Focus();
                }
            }
            
            if (errorMessage != "")
            {
                MessageBox.Show(errorMessage,errorTtile);
                return false;
            }
            else 
            {
                return true;
            }
        }

        public void updateProject(int i, string name, string budget, string spent, string time, string status)
        {
            //lstProjectList.Items[i] = name;
            program.Add(new Program(name, budget, spent, time, status));
            
            //program[i] = new Program(name, budget, spent, time, status);
        }

        private void btnCreateProject_click(object sender, RoutedEventArgs e)
        {
            if (ValidateInput(txtProjectName.Text, txtBudget.Text, txtSpent.Text, txtEstTimeRemaining.Text, comboBoxStatus.Text))
            {

                Program newProgram = new Program(
                    txtProjectName.Text,
                    txtBudget.Text,
                    txtSpent.Text,
                    txtEstTimeRemaining.Text,
                    comboBoxStatus.Text
                    );
                lstProjectList.Items.Add(newProgram.ProjectName);
                program.Add(newProgram);
                if(lstProjectList.SelectedIndex >=0)
                {
                    updateProject(lstProjectList.SelectedIndex, txtProjectName.Text, txtBudget.Text, txtSpent.Text, txtEstTimeRemaining.Text, comboBoxStatus.Text);
                }
                

            }
        }

        private void lstItemClicked(object sender, RoutedEventArgs e)
        {
            int listIndex = lstProjectList.SelectedIndex;
            //if (listIndex >= 0)
            //{
                // Selecting data to produce based on index value of the listbox
                Program pro = program[listIndex];
                //string msgoutput = "Project Name: " + pro.ProjectName + "\n" +
                 //        "Budget: " + pro.Budget + "\n" +
                 //        "Spent: " + pro.Spent + "\n" +
                  //       "Est Hours: " + pro.EstTimeRemaining + "\n" +
                  //       "Status: " + pro.ProjectStatus;
                ProjectDetails window = new ProjectDetails(pro.ProjectName, Convert.ToString(pro.Budget), Convert.ToString(pro.Spent), Convert.ToString(pro.EstTimeRemaining), pro.ProjectStatus);
                App.Current.MainWindow = window;
                window.Show();
                // Outputs required data to the user in the form of a MessageBox
                //MessageBox.Show(msgoutput);
                //txtProjectName.Focus();
            //}
            //int listIndex = lstProjectList.SelectedIndex;
            //if (listIndex >=0)
            //{
            //ProjectDetails projectDetails = new ProjectDetails(program);   
            //ProjectDetails window = new ProjectDetails(txtProjectName.Text, txtBudget.Text, txtSpent.Text, txtEstTimeRemaining.Text, comboBoxStatus.Text);
            //App.Current.MainWindow = window;
            //window.Show();
            //}
        }
    }
}
